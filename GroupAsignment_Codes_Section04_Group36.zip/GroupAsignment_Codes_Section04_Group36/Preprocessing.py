import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, StandardScaler
from category_encoders import BinaryEncoder
from sklearn.decomposition import PCA
from scipy.stats import zscore
import seaborn as sns

# Load the dataset
df = pd.read_csv("Accidental_Drug_Related_Deaths.csv")
pd.set_option('display.max_columns', None)
print(df.head())

# TODO 1: Data Cleaning
# ---------------- a. Handling Missing Values ----------------
# Step 1: Identify total number of missing values
print("Missing Values per column:\n", df.isnull().sum())
print("Dataset Shape: ", df.shape)

# Step 2: Verify data types
print(df.info())

# Step 3: Fill "Location if Other", "Other Significant Conditions ", "Other" with 'unknown'
fill_columns = ["Location if Other", "Other Significant Conditions ", "Other"]
df[fill_columns] = df[fill_columns].fillna("unknown")

# Step 4: Fill Numeric Columns with Mean
float_col = df.select_dtypes(include=['float64']).columns

df[float_col] = df[float_col].apply(lambda x: x.fillna(x.mean()))

# Step 5: Fill Missing Drug Data with 'N'
drug_columns = [
    "Heroin", "Heroin death certificate (DC)", "Cocaine", "Fentanyl",
    "Fentanyl Analogue", "Oxycodone", "Oxymorphone", "Ethanol", "Hydrocodone",
    "Benzodiazepine", "Methadone", "Meth/Amphetamine", "Amphet", "Tramad",
    "Hydromorphone", "Morphine (Not Heroin)", "Xylazine", "Gabapentin",
    "Opiate NOS", "Heroin/Morph/Codeine", "Other Opioid", "Any Opioid"
]
df[drug_columns] = df[drug_columns].apply(lambda col: col.fillna('N'))

# Step 6: Fill Categorical Columns with Mode
obj_cols = df.select_dtypes(include=['object']).columns
df[obj_cols] = df[obj_cols].apply(lambda x: x.fillna(x.mode()[0]))

# Step 7: Verify No Missing Values Remain
print("Missing Values after filling them:\n", df.isnull().sum())

# ---------------- b. Handling Duplicated Rows ----------------
# Step 1: Identify duplicated rows
duplicates = df.duplicated()
num_duplicates = duplicates.sum()
print(f"Number of duplicated rows: {num_duplicates}")

# Step 2: Conditionally remove duplicates only if they exist
if num_duplicates > 0:
    df = df.drop_duplicates()
    print("Duplicate rows removed.")
else:
    print("No duplicate rows found. No action needed.")

# ---------------- c. Handling Whitespaces ----------------
# Step 1: Trimming whitespaces in features (columns)
df.rename(columns={
    'Date Type': 'Date_Type',
    'Residence City': 'Residence_City',
    'Residence County': 'Residence_County',
    'Residence State': 'Residence_State',
    'Injury City': 'Injury_City',
    'Injury County': 'Injury_County',
    'Injury State': 'Injury_State',
    'Injury Place': 'Injury_Place',
    'Description of Injury': 'Description_of_Injury',
    'Death City': 'Death_City',
    'Death County': 'Death_County',
    'Death State': 'Death_State',
    'Location if Other': 'Other_location',
    'Other Significant Conditions ': 'Other_Condition',
    'Cause of Death': 'Cause_of_Death',
    'Manner of Death': 'Manner_of_Death',
    'Heroin death certificate (DC)': 'Heroin_DC',
    'Fentanyl Analogue': 'Fentanyl_Analogue',
    'Morphine (Not Heroin)': 'Morphine_Not_Heroin',
    'Opiate NOS': 'Opiate_NOS',
    'Other Opioid': 'Other_Opioid',
    'Any Opioid': 'Any_Opioid',
},
    inplace=True)

# Step 2: Trimming whitespaces in Rows (Records)
df.replace(to_replace={
    'Date_Type': r'\s+',
    'Ethnicity': r'\s+',
    'Residence_City': r'\s+',
    'Residence_County': r'\s+',
    'Residence_State': r'\s+',
    'Injury_City': r'\s+',
    'Injury_County': r'\s+',
    'Injury_State': r'\s+',
    'Injury_Place': r'\s+',
    'Description_of_Injury': r'\s+',
    'Death_City': r'\s+',
    'Death_County': r'\s+',
    'Death_State': r'\s+',
    'Other_location': r'\s+',
    'Cause_of_Death': r'\s+',
    'Manner_of_Death': r'\s+',
    'Heroin_DC': r'\s+',
    'ResidenceCityGeo': r'\s+',
    'InjuryCityGeo': r'\s+',
    'DeathCityGeo': r'\s+'
},
    value='_',
    regex=True,
    inplace=True)

# Step 3: Ensure whitespace is removed
print("Dataset after Removing Whitespace:")
print(df.head(5))

# ---------------- d. Fix the inconsistency ----------------
# Step 1: indetify the inconsistency
print("BEFORE FIXING INCONSISTENCY: ")
print("Date: ", df['Date'].unique())
print("Sex: ", df['Sex'].unique())
print("Location: ", df['Location'].unique())
print("Manner_of_Death: ", df['Manner_of_Death'].unique())
print("Fentanyl: ", df['Fentanyl'].unique())
print("Morphine_Not_Heroin: ", df['Morphine_Not_Heroin'].unique())
print("Gabapentin: ", df['Gabapentin'].unique())
print("Heroin/Morph/Codeine: ", df['Heroin/Morph/Codeine'].unique())
print("Other_Opioid:", df['Other_Opioid'].unique())

# Step 2: Fixing inconsistency
df['Date'] = df['Date'].replace(to_replace={r'/'}, value='-', regex=True)
df['Sex'] = df['Sex'].str.lower().replace({'x': 'unknown'}).str.title()

df['Location'] = df['Location'].replace(to_replace={
    'Hospital - Inpatient', 'Hospital - ER/Outpatient', 'Hospital - Dead On Arrival',
    'Hiospital'
}, value='Hospital')

df['Location'] = df['Location'].replace({'Other (Specify)': 'Other', "'Decedent's Home'": "Decedent's Home",
                                         'Hospice Facility': 'Hospice'})

df['Manner_of_Death'] = df['Manner_of_Death'].str.lower().replace({'acciddent': 'accident'}).str.title()
df['Fentanyl'] = df['Fentanyl'].str.lower().replace({'y pops': 'y', 'y (ptch)': 'y'}).str.title()
df['Morphine_Not_Heroin'] = df['Morphine_Not_Heroin'].str.lower().replace({
    'no rx but straws': 'y', 'stole meds': 'y', 'pcp neg': 'y'}).str.title()
df[['Gabapentin', 'Heroin/Morph/Codeine']] = df[['Gabapentin', 'Heroin/Morph/Codeine']].apply(
    lambda x: x.str.upper())
df['Other_Opioid'] = df['Other_Opioid'].str.lower().replace({
    'pcp': 'y', 'bupren': 'y', 'codeine': 'y', 'mdma': 'y', 'buprenorphine': 'y', 'difluro': 'y',
    'mdma, buprenorphine': 'y', 'ketamine': 'y', 'mitragynine': 'y', 'difluoro': 'y', 'protonitazene': 'y',
    'metonitazine': 'y', 'mitrag': 'y', 'bathsalt': 'y', 'mdma, lsd, ketamine': 'y'}).str.title()

# Step 3: indetify after fixing the inconsistency
print("AFTER FIXING INCONSISTENCY: ")
print("Date: ", df['Date'].unique())
print("Sex: ", df['Sex'].unique())
print("Location: ", df['Location'].unique())
print("Manner_of_Death: ", df['Manner_of_Death'].unique())
print("Fentanyl: ", df['Fentanyl'].unique())
print("Morphine_Not_Heroin: ", df['Morphine_Not_Heroin'].unique())
print("Gabapentin: ", df['Gabapentin'].unique())
print("Heroin/Morph/Codeine: ", df['Heroin/Morph/Codeine'].unique())
print("Other_Opioid:", df['Other_Opioid'].unique())

# ---------------- e. Detecting Outliers in Age Column ----------------
# Step 1: Calculate IQR
Q1 = df["Age"].quantile(0.25)
Q3 = df["Age"].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR

# Step 2: Identify outliers in Age
outliers = df[(df["Age"] < lower_bound) | (df["Age"] > upper_bound)]
print(f"Number of outliers in Age column: {outliers.shape[0]}")

# Step 3: Display the rows with outlier Age values
print("Outlier Records:")
print(outliers)

# Step 4: Optionally remove outliers
df = df[~df["Age"].isin(outliers["Age"])].reset_index(drop=True)
print("Outliers removed, if any existed.")

# TODO 2: Data Transformation
# TODO 2.1: ENCODING
# Step 1: Identifying the uniqueness of values in each object
df_noEC = df.copy()

categorical_cols = df_noEC.select_dtypes(include=['object']).columns
print("Unique Values in Features:\n", df_noEC[categorical_cols].nunique())

# Step 2: encode the categorical object

# uses label encoding
le_cols = ['Date_Type', 'Sex', 'Race', 'Ethnicity', 'Residence_City', 'Residence_County',
           'Residence_State', 'Injury_City', 'Injury_County', 'Injury_State', 'Injury_Place',
           'Description_of_Injury', 'Death_City', 'Death_County', 'Death_State', 'Location',
           'Other_location', 'Manner_of_Death', 'Other_Condition', 'Other']

label_encoder = {}

for col in le_cols:
    le = LabelEncoder()
    df_noEC[col] = le.fit_transform(df_noEC[col])
    label_encoder[col] = le

# uses binary encoding
be_drug = ['Heroin', 'Heroin_DC', 'Cocaine', 'Fentanyl', 'Ethanol', 'Fentanyl_Analogue', 'Oxycodone',
           'Oxymorphone', 'Hydrocodone', 'Benzodiazepine', 'Morphine_Not_Heroin', 'Methadone', 'Meth/Amphetamine',
           'Amphet', 'Tramad', 'Hydromorphone', 'Xylazine', 'Gabapentin', 'Opiate_NOS',
           'Heroin/Morph/Codeine', 'Any_Opioid', 'Other_Opioid']

mapping = {'Y': 1, 'N': 0, 'P': 2}

# Apply mapping to each column
for col in be_drug:
    df_noEC[col] = df_noEC[col].map(mapping)

# Apply Binary Encoding
be = BinaryEncoder(cols=be_drug)
df_encoded = be.fit_transform(df_noEC)

# step 3: handle geo columns
# Seperating them into 3 columns (City, ResCityLatitude, ResCityLongtitude)
df_noEC[['City', 'ResCityLatitude', 'ResCityLongitude']] = df_noEC['ResidenceCityGeo'].str.extract(
    r"([^,()]+),?_CT_\(([-\d.]+),_([-\d.]+)\)")
df_noEC[['City', 'InjuryCityLatitude', 'InjuryCityLongitude']] = df_noEC['InjuryCityGeo'].str.extract(
    r"([^,()]+),?_CT_\(([-\d.]+),_([-\d.]+)\)")
df_noEC[['City', 'DeathCityLatitude', 'DeathCityLongitude']] = df_noEC['DeathCityGeo'].str.extract(
    r"([^,()]+),?_CT_\(([-\d.]+),_([-\d.]+)\)")

# Change the data type to float
geo_col = ['ResCityLatitude', 'ResCityLongitude',
           'InjuryCityLatitude', 'InjuryCityLongitude',
           'DeathCityLatitude', 'DeathCityLongitude']

df_noEC[geo_col] = df_noEC[geo_col].astype(float)

# Fill the empty column with mean
df_noEC[geo_col] = df_noEC[geo_col].fillna(df_noEC[geo_col].mean())

# Drop unecessary columns
df_noEC.drop(columns=['City', 'ResidenceCityGeo', 'InjuryCityGeo', 'DeathCityGeo'], inplace=True)

# TODO 2.2: NORMALISATION
# Step 1: standardize the chosen numerical value
numeric_feature = ['ResCityLatitude', 'ResCityLongitude', 'InjuryCityLatitude', 'InjuryCityLongitude',
                   'DeathCityLatitude', 'DeathCityLongitude']

df_noEC[numeric_feature] = df_noEC[numeric_feature].apply(zscore)

# Step 2: Verifying that all the chosen values have been normalised
print("\nAfter Normalisation:\n",
      df_noEC[['ResCityLatitude', 'ResCityLongitude', 'InjuryCityLatitude', 'InjuryCityLongitude',
               'DeathCityLatitude', 'DeathCityLongitude']].head(10))

# TODO 2.3 Discretization
df_allCleaned = df_noEC.copy()

# Convert "Age" column to object
if 'Age' in df_allCleaned.columns:
    df_allCleaned['Age'] = df_allCleaned['Age'].astype(object)

# Defines the bins and labels respectively
bins = [0, 12, 20, 50, 100]
labels = ['Child', 'Adolescent', 'Adult', 'Senior']

# Apply discretisation without removing Age
df_allCleaned['Age_Group'] = pd.cut(df_allCleaned['Age'], bins=bins, labels=labels)

# Manually encode the "Age_Grouo: column
category_mapping = {'Child': 0, 'Adolescent': 1, 'Adult': 2, 'Senior': 3}
df_allCleaned['Age_Class'] = df_allCleaned['Age_Group'].map(category_mapping).astype(int)

print("\nAfter Discretisation of Age column:\n", df_allCleaned[['Age', 'Age_Group', 'Age_Class']].head())
print("new info: ", df_allCleaned.info())

# Export to Excel
# df_pca.to_excel("Accidental_Drug_Related_Death_Cleaned.xlsx", index=False)

print("---------------------------------------------------------------------------------------")
# TODO 3: ---- DATA REDUCTION

# Step 1: define a list that required to apply PCA
selected_features = ['Heroin', 'Heroin_DC', 'Cocaine', 'Fentanyl', 'Ethanol', 'Fentanyl_Analogue', 'Oxycodone',
           'Oxymorphone', 'Hydrocodone', 'Benzodiazepine', 'Morphine_Not_Heroin', 'Methadone', 'Meth/Amphetamine',
           'Amphet', 'Tramad', 'Hydromorphone', 'Xylazine', 'Gabapentin', 'Opiate_NOS',
           'Heroin/Morph/Codeine', 'Any_Opioid', 'Other_Opioid','Other']

# Standardized the numerical sets
scaler = StandardScaler()
drug_scaled = scaler.fit_transform(df_allCleaned[selected_features])

# Apply PCA without specifying n_components

# choose the n_components with 90% - 95% explained variance
n_components = 2
pca = PCA(n_components=n_components)
op_drug_pca = pca.fit_transform(drug_scaled)

pca_columns = [f'PC{i + 1}' for i in range(n_components)]
df_pca = pd.DataFrame(op_drug_pca, columns=pca_columns)

print("sample of dataset after PCA:\n", df_pca.head())


# Calculate the loading of original features onto a principal component
loading = pca.components_.T * np.sqrt(pca.explained_variance_)
l_df = pd.DataFrame(loading, columns=pca_columns, index=selected_features)

# Visualise the loading by heatmap
plt.figure(figsize=(12, 8))
sns.heatmap(l_df, annot=True, cmap="coolwarm", fmt=".2f", linewidths=0.5, annot_kws={"size": 5})
plt.title("PCA heatmap")
plt.xlabel("Principle Components")
plt.ylabel("Feature")
plt.show()

# Export to Excel
# df_pca.to_excel("Accidental_Drug_Related_Death_PCA.xlsx", index=False)