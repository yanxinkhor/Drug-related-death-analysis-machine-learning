import pandas as pd
import numpy as np
import sklearn

# Visualization
import matplotlib.pyplot as plt

# Classifiers
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB, BernoulliNB
from sklearn.ensemble import RandomForestClassifier

# Evaluation
from sklearn.model_selection import (train_test_split, StratifiedKFold,
                                     cross_val_predict, GridSearchCV)

# Metrics
from sklearn.metrics import (classification_report, confusion_matrix,
                             ConfusionMatrixDisplay)

# Performance Metric
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# Pipeline
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler

# Only for PyCharm
sklearn.set_config(print_changed_only=False)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
pd.set_option('display.max_rows', None)
pd.set_option('display.float_format', '{:.6f}'.format)  # Set float precision

# Load the dataset
df = pd.read_excel("Accidental_Drug_Related_Death_Cleaned.xlsx")

# --------------- Implementation of Data Mining Techniques ---------------
# Step 1: Select relevant features (Age, Sex & Drugs)
drug_columns = ['Heroin', 'Heroin_DC', 'Cocaine', 'Fentanyl', 'Ethanol', 'Fentanyl_Analogue', 'Oxycodone',
                'Oxymorphone', 'Hydrocodone', 'Benzodiazepine', 'Morphine_Not_Heroin', 'Methadone', 'Meth/Amphetamine',
                'Amphet', 'Tramad', 'Hydromorphone', 'Xylazine', 'Gabapentin', 'Opiate_NOS',
                'Heroin/Morph/Codeine', 'Any_Opioid', 'Other_Opioid']

# Count total drugs detected per individual
df['Drug_Count'] = df[drug_columns].sum(axis=1)

# Keep only relevant features
features = ['Age_Class', 'Sex'] + drug_columns + ['Drug_Count']
df = df[features]

zero_drug_count = df[df['Drug_Count'] == 0]
print("Number of rows with 0 Drug Count:", len(zero_drug_count))
df = df[df['Drug_Count'] > 0]

# Step 2: Create Risk_Level
df['Risk_Level'] = pd.qcut(df['Drug_Count'] + df['Age_Class'] + df['Sex'], q=3,
                           labels=[0, 1, 2])  # 0=Low, 1=Medium, 2=High

# Step 3: Prepare for classification
features = ['Age_Class', 'Sex'] + drug_columns
X = df[features]
y = df['Risk_Level']

# Spliting (train 70%/test 30%)
X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    test_size=0.3,
                                                    shuffle=True,
                                                    random_state=42)

# Step 4: Pipeline setup
# Pipe 1 (Numeric Features - Imputation & StandardScaler)
numeric_features = X.select_dtypes(np.number).columns
numeric_transformer = Pipeline(steps=[('imputer', SimpleImputer(strategy='median')),
                                      ('scaler', StandardScaler())])
print("Before transformation:")
print("# of numeric features: ", len(numeric_features))
print("Numeric Features:", list(numeric_features))

# Main pipe
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
    ],
    remainder='drop',
    verbose=True)

# Step 5: Apply Pipeline (X_train)
X_train = preprocessor.fit_transform(X_train)
print("After transformation:")
print("X_train shape:", X_train.shape)
print("First 5 rows:\n", pd.DataFrame(X_train).head())  # Print only first 5 rows

# Convert X_train to Dataframe for better visualization
X_train = pd.DataFrame(data=X_train, columns=numeric_features)

# Step 6: Apply pipeline (X-test)
X_test = preprocessor.transform(X_test)
X_test = pd.DataFrame(data=X_test, columns=numeric_features)

# Step 7: Model Training (Choose ONE classifier)
classifiers = {
    'Decision Tree': DecisionTreeClassifier(random_state=42),
    'Naive Bayes (Gaussian)': GaussianNB(),
    'Naive Bayes (Bernoulli)': BernoulliNB(),
    'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=10, class_weight='balanced', random_state=42)
}

# Step 8: Store the results
results = []

# --------------- Evaluation and Validation of Models ---------------
# TODO 1: Check performance & Visualization
for name, clf in classifiers.items():
    print("\n" + "=" * 50)
    print(f"MODEL: {name}")
    print("=" * 50)

    # Train the model
    clf.fit(X_train, y_train)

    # Predict on test set
    prediction = clf.predict(X_test)

    # Print model parameters
    print("\nModel Parameters:")
    for param, value in clf.get_params().items():
        print(f"  {param}: {value}")

    # Calculate performance metrics
    acc = accuracy_score(y_test, prediction) * 100
    prec = precision_score(y_test, prediction, average='macro') * 100
    rec = recall_score(y_test, prediction, average='macro') * 100
    f1 = f1_score(y_test, prediction, average='macro') * 100

    # Store results
    results.append([name, acc, prec, rec, f1])

    # Print metrics
    print("\nPerformance Metrics:")
    print(f"  Accuracy : {acc:.2f}%")
    print(f"  Precision: {prec:.2f}%")
    print(f"  Recall   : {rec:.2f}%")
    print(f"  F1 Score : {f1:.2f}%")

    print("=" * 50 + "\n")

# Confusion Matrix and Classification Report for the DecisionTreeClassifier
# Classification Report
classes = ['Low Risk', 'Medium Risk', 'High Risk']
print("\nClassification Report: \n", classification_report(y_test, prediction,
                                                           target_names=classes,
                                                           zero_division=1))

# Confusion Matrix
cm = confusion_matrix(y_test, prediction)
print("\nTabular CM")

# Displaying Confusion Matrix
disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=classes)
disp.plot(cmap=plt.cm.Blues)
plt.title('Confusion Matrix', fontsize=15, pad=20)
plt.xlabel('Prediction', fontsize=11)
plt.ylabel('Actual', fontsize=11)
# Customizations
plt.gca().xaxis.set_label_position('top')
plt.gca().xaxis.tick_top()
plt.gca().figure.subplots_adjust(bottom=0.2)
plt.gca().figure.text(0.5, 0.05, 'Prediction', ha='center', fontsize=13)
plt.show()

# TODO 2: Cross Validation & Ensemble
# Step 1: Data Setup
X1 = df.drop(columns=['Risk_Level'])
y1 = df['Risk_Level']

# Step 2: Setup Cross-validation
MyCV = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
model = RandomForestClassifier(random_state=42)

# Step 3: Perform cross-validation and get predictions
y_pred = cross_val_predict(model, X1, y1, cv=MyCV)

# Step 4: Display classification report with per-class accuracy
risk_labels = ['Low Risk', 'Medium Risk', 'High Risk']
report = classification_report(y1, y_pred, target_names=risk_labels, zero_division=1)
print("\nCross-validation Classification Report:\n", report)

# --------------- Data Visualization and Interpretation ---------------
# Step 1: Convert results to DataFrame
results_df = pd.DataFrame(results, columns=['Model', 'Accuracy', 'Precision', 'Recall', 'F1 Score'])

# Step 2: Set figure size
plt.figure(figsize=(15, 8))

# Step 3: Plotting bar chart
# Bar chart 1: Accuracy
plt.subplot(2, 2, 1)
bars1 = plt.bar(results_df['Model'], results_df['Accuracy'], color='skyblue')
plt.title('Accuracy (%)', fontsize=14)
plt.ylabel('Score')
plt.ylim(0, 100)
for bar in bars1:
    plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1, f"{bar.get_height():.2f}%", ha='center',
             fontsize=10)

# Bar chart 2: Precision
plt.subplot(2, 2, 2)
bars2 = plt.bar(results_df['Model'], results_df['Precision'], color='lightgreen')
plt.title('Precision (%)', fontsize=14)
plt.ylabel('Score')
plt.ylim(0, 100)
for bar in bars2:
    plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1, f"{bar.get_height():.2f}%", ha='center',
             fontsize=10)

# Bar chart 3: Recall
plt.subplot(2, 2, 3)
bars3 = plt.bar(results_df['Model'], results_df['Recall'], color='salmon')
plt.title('Recall (%)', fontsize=14)
plt.ylabel('Score')
plt.ylim(0, 100)
for bar in bars3:
    plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1, f"{bar.get_height():.2f}%", ha='center',
             fontsize=10)

# Bar chart 4: F1 Score
plt.subplot(2, 2, 4)
bars4 = plt.bar(results_df['Model'], results_df['F1 Score'], color='plum')
plt.title('F1 Score (%)', fontsize=14)
plt.ylabel('Score')
plt.ylim(0, 100)
for bar in bars4:
    plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1, f"{bar.get_height():.2f}%", ha='center',
             fontsize=10)

# Add overall title
plt.suptitle('Model Performance Comparison', fontsize=18)

# Adjust spacing
plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.show()


