# TODO: Import necessary packages
import pandas as pd
import numpy as np

# For Visualisation
import matplotlib.pyplot as plt
import seaborn as sns

# For Resampling
from imblearn.combine import SMOTETomek, SMOTEENN
from imblearn.over_sampling import SMOTE, ADASYN
from imblearn.under_sampling import RandomUnderSampler, NearMiss

# For logistic regression implemnentation
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, GridSearchCV

# Import Different Metrics for evaluation
from sklearn.metrics import (classification_report,
                             confusion_matrix,
                             ConfusionMatrixDisplay,
                             accuracy_score,
                             f1_score,
                             recall_score,
                             precision_score,
                             roc_curve, auc)

# Step 1: PyCharm Set Up
desired_width = 5000
pd.set_option('display.width', desired_width)
np.set_printoptions(linewidth=desired_width)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
pd.set_option('display.max_rows', None)

# Step 2: Load dataset
data = pd.read_excel("Accidental_Drug_Related_Death_Cleaned.xlsx")

# Step 3: Make a copy
df = data.copy()

# TODO: Implementation of Logistic Regression
# Step 1: Define drug-related features
drug_columns = ['Heroin', 'Heroin_DC', 'Cocaine', 'Fentanyl', 'Ethanol', 'Fentanyl_Analogue', 'Oxycodone',
                'Oxymorphone', 'Hydrocodone', 'Benzodiazepine', 'Morphine_Not_Heroin', 'Methadone',
                'Meth/Amphetamine', 'Amphet', 'Tramad', 'Hydromorphone', 'Xylazine', 'Gabapentin',
                'Opiate_NOS', 'Heroin/Morph/Codeine', 'Any_Opioid', 'Other_Opioid']

# Step 2: Count total drugs detected per individual
df['Drug_Count'] = df[drug_columns].sum(axis=1)

# Step 3: Keep only relevant features
features = ['Age_Class', 'Sex', 'Ethnicity', 'Race'] + drug_columns + ['Drug_Count']
df = df[features]

# Step 4: Remove individuals with no drug use
df = df[df['Drug_Count'] > 0]

# Step 5:Remove invalid values
df = df[df['Sex'].isin([0, 1])]

# Step 6: One-hot encoding for 'Age_Class'
df = pd.get_dummies(df, columns=['Age_Class'], drop_first=True)

# Step 7: Define features and target
X = df.drop(columns=['Sex'])
y = df['Sex']

# Step 8: Perform Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y,
                                                    test_size=0.3,
                                                    stratify=y,
                                                    random_state=42)

# TODO: Perform Resampling technique
# Step 1: Visualise different resampling techniques
# Define Resampling techniques
resamplers = {
    'No Resampling': None,
    'SMOTE': SMOTE(random_state=42),
    'ADASYN': ADASYN(random_state=42),
    'RandomUnderSampler': RandomUnderSampler(random_state=42),
    'NearMiss': NearMiss(),
    'SMOTETomek': SMOTETomek(random_state=42),
    'SMOTEENN': SMOTEENN(random_state=42)
}

# Store results for plotting
results = {}

# Evaluate performance for each resampling technique
for name, resampler in resamplers.items():
    X_train_resampled = X_train
    y_train_resampled = y_train

    if resampler:
        X_train_resampled, y_train_resampled = resampler.fit_resample(X_train, y_train)

    # Train Logistic Regression
    model = LogisticRegression(random_state=42, max_iter=2000)
    model.fit(X_train_resampled, y_train_resampled)

    # Make an assumption
    y_pred = model.predict(X_test)
    y_pred_prob = model.predict_proba(X_test)[:, 1]

    # evaluate based on metrics
    accuracy = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)

    results[name] = {
        'accuracy': accuracy,
        'f1': f1,
        'precision': precision,
        'recall': recall,
    }


metrics = ['accuracy', 'f1', 'precision', 'recall']
num_resamplers = len(results)
num_metrics = len(metrics)
index = np.arange(num_resamplers)

df_results = pd.DataFrame(results).T.reset_index().melt(id_vars="index", var_name="Metric", value_name="Score")

# plotting the metrics to compare among them
plt.figure(figsize=(12, 6))
sns.barplot(data=df_results, x="index", y="Score", hue="Metric", palette="viridis")

plt.xlabel("Resampling Technique")
plt.ylabel("Score")
plt.title("Performance Comparison of Resampling Techniques")
plt.xticks(rotation=45, ha='right')
plt.legend(title="Metric")
plt.tight_layout()
plt.show()


# Step 2: Apply SMOTE for class balancing after comparing different resampling technique
smote = SMOTE(random_state=42)
X_train_resampled, y_train_resampled = smote.fit_resample(X_train, y_train)

model = LogisticRegression(random_state=42, max_iter=2000)
model.fit(X_train_resampled, y_train_resampled)


# TODO: Evaluation and Validation
# Step 1: Define hyperparameter for tuning
param_grid = {
    'C': [0.01, 0.1, 1, 10, 100],
    'solver': ['liblinear', 'newton-cg', 'saga'],
    'penalty': ['l2']
}

# Step 3: Perform grid search
grid_search = GridSearchCV(LogisticRegression(random_state=42, max_iter=2000),
                           param_grid, cv=5, scoring='accuracy')

grid_search.fit(X_train_resampled, y_train_resampled)

# Step 4: Verify the best parameters
print("Best Parameters:", grid_search.best_params_)

best_model = LogisticRegression(random_state=42,
                                C=grid_search.best_params_['C'],
                                solver=grid_search.best_params_['solver'],
                                max_iter=2000)

best_model.fit(X_train_resampled, y_train_resampled)

# Step 5: Make predictions on the optimal model
y_pred = best_model.predict(X_test)
y_pred_prob = best_model.predict_proba(X_test)[:, 1]

# Step 6: Evaluate based on Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot(cmap='Blues')
plt.title("Confusion Matrix")
plt.show()

# Step 7: Verify the result based on Classification Report
print("Classification Report:\n")
print(classification_report(y_test, y_pred))

# Step 8: Define the metrics for evaluation
f1 = f1_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
accuracy = accuracy_score(y_test, y_pred)

# Step 9: Verify the result
print("\nEvaluation Result:\n")
print(f"Accuracy: {accuracy * 100:.2f}%")
print(f"F1 Score: {f1 * 100:.2f}%")
print(f"Recall: {recall * 100:.2f}%")
print(f"Precision: {precision * 100:.2f}%")


# Step 10: Visualise the ROC for the best model
# Compute ROC curve for the best model
y_pred_prob_best = best_model.predict_proba(X_test)[:, 1]
fpr, tpr, threshold = roc_curve(y_test, y_pred_prob_best)
roc_auc = auc(fpr, tpr)

# Plot ROC curve for the best model
plt.figure(figsize=(8, 6))
plt.plot(fpr, tpr, label=f"Best Model (AUC={roc_auc:.2f})", color='blue')

# Baseline (Random Classifier)
plt.plot([0, 1], [0, 1], color='gray', linestyle='--')

# Labels & Legends
plt.xlabel('False Positive Rate (FPR)')
plt.ylabel('True Positive Rate (TPR)')
plt.title('ROC Curve for Best Logistic Regression Model')
plt.legend()
plt.grid()
plt.show()

