import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.metrics import (silhouette_score,
                             davies_bouldin_score,
                             calinski_harabasz_score)


# Step 1: Set up the view for PyCharm
desired_width = 5000
pd.set_option('display.width', desired_width)
np.set_printoptions(linewidth=desired_width)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)
pd.set_option('display.max_rows', None)
# TODO: Clustering

# TODO 1: ---- K-Mean Clustering
# Step 1: Load the PCA dataset
df = pd.read_excel("Accidental_Drug_Related_Death_PCA.xlsx")

# Step 2: Define K-means Functions
# Define a random centroids
def random_centroids(data, k):
    """Select k unique random sample from the dataset as initial centroid"""
    return data.sample(n=k, random_state=42).reset_index(drop=True).T

#  Define label for K-means
def get_labels(data, centroid):
    """Assign each daya point to the closest cectroid using Euclidean distance"""
    distances = centroid.apply(lambda x: np.sqrt(((data - x) ** 2).sum(axis=1)), axis=0)
    return distances.idxmin(axis=1)

# Define a new centroids
def new_centroids(data, labels, k):
    """Recompute the centroid by calculating the mean of all points in each cluster"""
    return data.groupby(labels).mean().T


# Step 3: Define metrics for KMeans Clustering
silhouette_all = [] # Store Silhoutte score for different cluster size
SSE = [] # Stores sum of Squared Error for each cluster count
db_index = [] # Stores Davies-Bouldin index for evaluation
ch_score = [] # Stores Calinski-Harabasz score

# Step 4: Determine optimal k based on Elbow method
k = range(2, 13)
for clusters in k:
    kmeans = KMeans(n_clusters=clusters, random_state=42, n_init=10)
    labels = kmeans.fit_predict(df)

    silhouette_all.append(silhouette_score(df, labels))
    db_index.append(davies_bouldin_score(df, labels))
    ch_score.append(calinski_harabasz_score(df, labels))
    SSE.append(kmeans.inertia_)


# Step 5: Plotting each metrics
# Visualise silhoutte score
plt.figure(figsize=(10, 6))
plt.plot(k, silhouette_all, linestyle='-', color='red')
plt.xlabel('Number of Cluster')
plt.ylabel("Inertia")
plt.title("Silhouette Score for Different Cluster (Kmeans)")
plt.show()

# Visualise Davies-Bouldin Index (Lower is Better)
plt.figure(figsize=(10, 6))
plt.plot(k, db_index, marker='o', linestyle='-', color='red')
plt.xlabel("Number of Cluster")
plt.ylabel("Davies-Bouldin Index")
plt.title("Davies-Bouldin Index for different Cluster Numbers (Lower is Better)")
plt.show()

# Visualise Calinski-Harabasz Score (Higer is Better)
plt.figure(figsize=(10, 6))
plt.plot(k, ch_score, marker='o', linestyle='-', color='red')
plt.xlabel('Number of Cluster')
plt.ylabel("Calinski-Harabasz Score")
plt.title("Calinski-Harabasz Score for Different Cluster Number (Higher is better)")
plt.show()

# Visualise SSE
plt.figure(figsize=(12, 6))
plt.plot(k, SSE, marker='o',linestyle='-', color='red')
plt.xlabel('Number of Cluster')
plt.ylabel("Inertia")
plt.title("Elbow Method for Different Cluster (Kmeans)")
plt.show()

# Step 6: Initial various value for K-means clustering
optimal_k = 4 # set the optimal k to be 4
max_iterations = 100 # set the maximum ieteration to be 100

labels = pd.Series(dtype=int)  # Empty label series
centroid = random_centroids(df, optimal_k)  # Initialise centroid
old_centroid = pd.DataFrame()  # Store previous centroid for convergence check

iteration = 1 # set the initial iteration to be 1
snapshots = []  # Store snapshots for visualization

# Step 7: append the iteration to snapshot for future representation
while iteration < max_iterations and not centroid.equals(old_centroid):
    old_centroid = centroid
    labels = get_labels(df, centroid)
    centroid = new_centroids(df, labels, optimal_k)

    # Store snapshot
    if iteration % 5 == 0 or iteration == 1:
        snapshots.append((iteration, labels.copy(), centroid.copy()))

    iteration += 1

# Final Snapshot
snapshots.append((iteration - 1, labels.copy(), centroid.copy()))

# Step 8: Analyze CLuster Characteristics
# Assign final labels to the data frame
df['Cluster'] = labels.values

cluster_summary = df.groupby("Cluster")[["PC1", "PC2"]].mean()
print("\nCluster Summary:")
print(cluster_summary)

# Step 9: Assign an appropriate cluster name based on the cluster_summary
cluster_name = {
    0: "Dabbler (Minimal or no Drug Use)",
    1: "Extensive Regulars (Opioid-Dominant)",
    2: "Casual Regular (Synthetic-Opioid)",
    3: "Committed Users (Mix Consumption)",
}

# Step 10: Assign color to each cluster for clearer representation
color_label = {0: "purple",
               1: "teal",
               2: "yellow",
               3: "blue"}

# Step 11: Define a function to plot the cluster
def plot_cluster(data, labels, centroids, iteration, final=False):
    """Plot the clusters and centroids"""
    plt.figure(figsize=(8, 6))
    title = 'Final Cluster' if final else f'Iteration {iteration}'
    plt.title(title + "(Addiction Level)")

    # Convert DataFrame to NumPy array for indexing
    data_np = data.iloc[:, :2].values

    # Plot each cluster with its own color
    for cluster in np.unique(labels):
        subset = data_np[labels == cluster]
        plt.scatter(subset[:, 0], subset[:, 1],
                    c=color_label[cluster],
                    edgecolors="k",
                    label=cluster_name.get(cluster, f"Cluster {cluster}"),
                    alpha=0.6)

    # Ensure centroids are NumPy array
    centroids_np = centroids.T.values if isinstance(centroids, pd.DataFrame) else centroids.T

    # Plot centroids
    plt.scatter(centroids_np[:, 0], centroids_np[:, 1], c='red', marker='X', s=120, label="Centroids")
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.legend()
    plt.show()

# Step 12: Plot each snapshot of the clustering
for iter_num, lbls, cntrs in snapshots:
    plot_cluster(df, lbls, cntrs, iter_num, final=(iter_num == iteration - 1))


print("\nCluster Distribution:")
print(df['Cluster'].map(cluster_name).value_counts())

print("\nAddicted Level:")
for cluster_num, cluster_label in cluster_name.items():
    print(f"Cluster {cluster_num}: {cluster_label}")
    print(df[df['Cluster'] == cluster_num].head(10), "\n")


# TODO 2: Evaluation on K-mean Clustering
# Step 1: Compute each metrics score for k-means clustering
sil_score = silhouette_score(df, df['Cluster'])
db_index = davies_bouldin_score(df, df['Cluster'])
ch_score = calinski_harabasz_score(df, df['Cluster'])
sse = ((df.iloc[:, :2] - centroid.T.loc[df['Cluster']].values) ** 2).sum(axis=1).sum()

# Step 2: Print Results in a Properly Aligned Table
print("+--------------------------------------+----------------------+")
print("|            Metrics                   |        Result        |")
print("+--------------------------------------+----------------------+")
print(f"| Silhouette Score                     | {sil_score:.4f}               |")
print(f"| Davies-Bouldin Index                 | {db_index:.4f}               |")
print(f"| Calinski-Harabasz Score              | {ch_score:.2f}             |")
print(f"| SSE (Sum of Squared Errors)          | {sse:.2f}              |")
print("+--------------------------------------+----------------------+")

# TODO 3: Visualisation
# Visualise the count of data point based on the cluster
df['Cluster'].map(cluster_name).value_counts().plot(kind='bar', color='lightcoral')
plt.xlabel("Cluster Label")
plt.ylabel("Count of Data Points")
plt.xticks(rotation=45)
plt.title("Cluster Distribution")
plt.show()
